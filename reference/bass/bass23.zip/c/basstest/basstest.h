#define ID_MODLIST						10
#define ID_MODPLAY                      11
#define ID_MODSTOP						12
#define ID_MODRESTART					13
#define ID_MODADD						14
#define ID_MODREMOVE					15

#define ID_SAMLIST						20
#define ID_SAMPLAY						21
#define ID_SAMADD						22
#define ID_SAMREMOVE					23

#define ID_STRLIST                      30
#define ID_STRPLAY						31
#define ID_STRSTOP						32
#define ID_STRRESTART                   33
#define ID_STRADD                       34
#define ID_STRREMOVE                    35

#define ID_CPU							40
#define ID_STOP							41
#define ID_RESUME						42
