#define ID_OPEN                         10
#define ID_OPEN2                        11

#define ID_DEVLIST						2001
#define ID_LOWQUAL						2002
